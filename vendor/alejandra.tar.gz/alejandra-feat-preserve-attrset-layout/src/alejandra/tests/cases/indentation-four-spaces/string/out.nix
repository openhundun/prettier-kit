[
    ''
         foo
        bar
    ''
]
