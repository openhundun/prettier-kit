[
  ''
     foo
    bar
  ''
]
