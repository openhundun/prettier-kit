[
  (assert b; e)
  (assert b;
    /*
    d
    */
      e)
  (assert b; e)
  (assert b;
    /*
    d
    */
      e)
  (assert
    /*
    a
    */
    b; e)
  (assert
    /*
    a
    */
    b;
    /*
    d
    */
      e)
  (assert
    /*
    a
    */
    b; e)
  (assert
    /*
    a
    */
    b;
    /*
    d
    */
      e)
  (assert b; cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc)
  (assert b; cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc)
]
