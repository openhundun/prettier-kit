[
	''
     foo
    bar
  ''
]
