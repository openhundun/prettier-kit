[
  ''a''
  ''single line content''
]
