[
	''a''
	''single line content''
]
