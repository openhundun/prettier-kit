[
	''
    foo

    bar
  ''
]
