[
  ''
    foo

    bar
  ''
]
