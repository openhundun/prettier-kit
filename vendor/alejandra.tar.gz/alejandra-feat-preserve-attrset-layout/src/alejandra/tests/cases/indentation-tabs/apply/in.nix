{
  foo =
      bar:
          baz:
            fnbody;
}
