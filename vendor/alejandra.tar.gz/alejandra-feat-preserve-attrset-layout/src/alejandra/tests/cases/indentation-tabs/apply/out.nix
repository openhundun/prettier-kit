{
	foo = bar: baz:
		fnbody;
}
