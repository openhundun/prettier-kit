use crate::config::Config;
use crate::config::Indentation;

#[derive(PartialEq)]
pub(crate) enum Step {
    Comment(String),
    Dedent,
    Format(rnix::SyntaxElement),
    FormatWider(rnix::SyntaxElement),
    Indent,
    NewLine,
    Pad,
    Token(rnix::SyntaxKind, String),
    Whitespace,
}

#[derive(Clone)]
pub(crate) struct BuildCtx {
    pub config:                       Config,
    pub fitting_in_single_line_depth: usize,
    pub force_wide:                   bool,
    pub force_wide_success:           bool,
    pub indentation:                  usize,
    pub pos_old:                      crate::position::Position,
    pub path:                         String,
    pub vertical:                     bool,
}

impl BuildCtx {
    /// Compute the indent string for the current indentation level,
    /// respecting the configured indentation style.
    pub(crate) fn indent_str(&self) -> String {
        let unit = match self.config.indentation {
            Indentation::FourSpaces => "    ",
            Indentation::Tabs => "\t",
            Indentation::TwoSpaces => "  ",
        };
        unit.repeat(self.indentation)
    }
}

pub(crate) fn build(
    build_ctx: &mut BuildCtx,
    element: rnix::SyntaxElement,
) -> Option<rowan::GreenNode> {
    let mut builder = rowan::GreenNodeBuilder::new();

    build_step(&mut builder, build_ctx, &crate::builder::Step::Format(element));

    if build_ctx.force_wide {
        if build_ctx.force_wide_success {
            Some(builder.finish())
        } else {
            None
        }
    } else {
        Some(builder.finish())
    }
}

fn build_step(
    builder: &mut rowan::GreenNodeBuilder,
    build_ctx: &mut BuildCtx,

    step: &crate::builder::Step,
) {
    if build_ctx.force_wide && !build_ctx.force_wide_success {
        return;
    }

    match step {
        crate::builder::Step::Comment(text) => {
            let mut lines: Vec<String> =
                text.lines().map(|line| line.trim_end().to_string()).collect();

            let indent = build_ctx.indent_str();
            lines = lines
                .iter()
                .enumerate()
                .map(|(index, line)| {
                    if index == 0 || line.is_empty() {
                        line.to_string()
                    } else {
                        format!("{}{}", indent, line)
                    }
                })
                .collect();

            add_token(
                builder,
                rnix::SyntaxKind::TOKEN_COMMENT,
                &lines.join("\n"),
            );
        }
        crate::builder::Step::Dedent => {
            build_ctx.indentation -= 1;
        }
        crate::builder::Step::Format(element) => {
            format(builder, build_ctx, element);
        }
        crate::builder::Step::FormatWider(element) => {
            format_wider(builder, build_ctx, element);
        }
        crate::builder::Step::Indent => {
            build_ctx.indentation += 1;
        }
        crate::builder::Step::NewLine => {
            build_ctx.force_wide_success = false;

            add_token(builder, rnix::SyntaxKind::TOKEN_WHITESPACE, "\n");
        }
        crate::builder::Step::Pad => {
            if build_ctx.indentation > 0 {
                add_token(
                    builder,
                    rnix::SyntaxKind::TOKEN_WHITESPACE,
                    &match build_ctx.config.indentation {
                        Indentation::FourSpaces => "    ",
                        Indentation::Tabs => "\t",
                        Indentation::TwoSpaces => "  ",
                    }
                    .repeat(build_ctx.indentation),
                );
            }
        }
        crate::builder::Step::Token(kind, text) => {
            add_token(builder, *kind, text);
        }
        crate::builder::Step::Whitespace => {
            add_token(builder, rnix::SyntaxKind::TOKEN_WHITESPACE, " ");
        }
    }
}

fn add_token(
    builder: &mut rowan::GreenNodeBuilder,
    kind: rnix::SyntaxKind,
    text: &str,
) {
    builder.token(rowan::SyntaxKind(kind as u16), text);
}

fn format(
    builder: &mut rowan::GreenNodeBuilder,
    build_ctx: &mut BuildCtx,
    element: &rnix::SyntaxElement,
) {
    let kind = element.kind();

    match element {
        rnix::SyntaxElement::Node(node) => {
            builder.start_node(rowan::SyntaxKind(kind as u16));

            let rule = match kind {
                // a b
                rnix::SyntaxKind::NODE_APPLY => crate::rules::apply::rule,

                // assert a; b
                rnix::SyntaxKind::NODE_ASSERT => crate::rules::scoped::rule,

                // a.b.c
                rnix::SyntaxKind::NODE_ATTRPATH => crate::rules::default,

                // a = b;
                rnix::SyntaxKind::NODE_ATTRPATH_VALUE => {
                    crate::rules::key_value::rule
                }

                // { }
                rnix::SyntaxKind::NODE_ATTR_SET => crate::rules::attr_set::rule,

                // a $op b
                rnix::SyntaxKind::NODE_BIN_OP => crate::rules::bin_op::rule,

                // __loc__ (current position)
                rnix::SyntaxKind::NODE_CUR_POS => crate::rules::default,

                // ${a} (interpolation but for NODE_SELECT)
                rnix::SyntaxKind::NODE_DYNAMIC => crate::rules::dynamic::rule,

                //
                rnix::SyntaxKind::NODE_HAS_ATTR => crate::rules::default,

                // $identifier
                rnix::SyntaxKind::NODE_IDENT => crate::rules::default,
                rnix::SyntaxKind::NODE_IDENT_PARAM => crate::rules::default,

                // if a then b else c
                rnix::SyntaxKind::NODE_IF_ELSE => crate::rules::if_else::rule,

                // inherit NODE_INHERIT_FROM? b+ ;
                rnix::SyntaxKind::NODE_INHERIT => crate::rules::inherit::rule,

                // ( a )
                rnix::SyntaxKind::NODE_INHERIT_FROM => {
                    crate::rules::paren::rule
                }

                // ${a}
                rnix::SyntaxKind::NODE_INTERPOL => crate::rules::paren::rule,

                // a: b
                rnix::SyntaxKind::NODE_LAMBDA => crate::rules::lambda::rule,

                // let { }
                rnix::SyntaxKind::NODE_LEGACY_LET => crate::rules::default,

                // let NODE_KEY_VALUE* in b;
                rnix::SyntaxKind::NODE_LET_IN => crate::rules::let_in::rule,

                // [ ... ]
                rnix::SyntaxKind::NODE_LIST => crate::rules::list::rule,

                // 1 | true | null
                rnix::SyntaxKind::NODE_LITERAL => crate::rules::default,

                // ( a )
                rnix::SyntaxKind::NODE_PAREN => crate::rules::paren::rule,

                // a | a ? b
                rnix::SyntaxKind::NODE_PAT_BIND => crate::rules::pat_bind::rule,

                // NODE_PAT_BIND | TOKEN_ELLIPSIS
                rnix::SyntaxKind::NODE_PAT_ENTRY => {
                    crate::rules::pat_entry::rule
                }

                // /path/to/${a} (absolute path)
                rnix::SyntaxKind::NODE_PATH_ABS => crate::rules::default,

                // ~/ (home path)
                rnix::SyntaxKind::NODE_PATH_HOME => crate::rules::default,

                // /path/to/${a} (relative path)
                rnix::SyntaxKind::NODE_PATH_REL => crate::rules::default,

                // <path> (search path)
                rnix::SyntaxKind::NODE_PATH_SEARCH => crate::rules::default,

                // { NODE_PAT_ENTRY* }
                rnix::SyntaxKind::NODE_PATTERN => crate::rules::pattern::rule,

                // implementation detail of rowan
                rnix::SyntaxKind::NODE_ROOT => crate::rules::root::rule,

                // a.b | a.NODE_DYNAMIC
                rnix::SyntaxKind::NODE_SELECT => crate::rules::default,

                // "..." || ''...''
                rnix::SyntaxKind::NODE_STRING => crate::rules::string::rule,

                // !a
                rnix::SyntaxKind::NODE_UNARY_OP => crate::rules::default,

                // with a; b
                rnix::SyntaxKind::NODE_WITH => crate::rules::scoped::rule,
                kind => {
                    panic!(
                        "Missing rule for {:?} at: {}",
                        kind, build_ctx.path
                    );
                }
            };

            for step in rule(build_ctx, node) {
                build_step(builder, build_ctx, &step);
            }

            builder.finish_node();
        }
        rnix::SyntaxElement::Token(token) => {
            let text = token.text();
            add_token(builder, kind, text);
            build_ctx.pos_old.update(text);
        }
    }
}

fn format_wider(
    builder: &mut rowan::GreenNodeBuilder,
    build_ctx: &mut BuildCtx,
    element: &rnix::SyntaxElement,
) {
    match element {
        rnix::SyntaxElement::Node(node) => {
            let mut build_ctx_clone = build_ctx.clone();

            build_ctx_clone.vertical =
                !fits_in_single_line(build_ctx, node.clone().into());

            format(builder, &mut build_ctx_clone, element);
        }
        rnix::SyntaxElement::Token(_) => {
            format(builder, build_ctx, element);
        }
    };
}

pub(crate) fn fits_in_single_line(
    build_ctx_old: &crate::builder::BuildCtx,
    element: rnix::SyntaxElement,
) -> bool {
    let mut build_ctx = crate::builder::BuildCtx {
        force_wide: true,
        force_wide_success: true,
        vertical: false,
        ..build_ctx_old.clone()
    };

    build_ctx.fitting_in_single_line_depth += 1;

    if build_ctx.fitting_in_single_line_depth >= 2 {
        return true;
    }

    let fits = build(&mut build_ctx, element).is_some();

    build_ctx.fitting_in_single_line_depth -= 1;

    fits
}

pub(crate) fn make_isolated_token(
    kind: rnix::SyntaxKind,
    text: &str,
) -> rnix::SyntaxToken {
    use rowan::Language;

    let mut builder = rowan::GreenNodeBuilder::new();
    builder.start_node(rnix::NixLanguage::kind_to_raw(
        rnix::SyntaxKind::NODE_ROOT,
    ));
    builder.token(rnix::NixLanguage::kind_to_raw(kind), text);
    builder.finish_node();

    let node = builder.finish();

    rnix::SyntaxNode::new_root(node).first_token().unwrap()
}
