{
  description = "The Uncompromising Nix Code Formatter";

  inputs = {
    fenix.url = "github:nix-community/fenix";
    fenix.inputs.nixpkgs.follows = "nixpkgs";

    flakeCompat.url = "github:edolstra/flake-compat";
    flakeCompat.flake = false;

    nixpkgs.url = "github:nixos/nixpkgs/nixos-unstable-small";
  };

  outputs = inputs: let
    commit = inputs.self.shortRev or "dirty";
    date = inputs.self.lastModifiedDate or inputs.self.lastModified or "19700101";
    version = "4.1.0+${builtins.substring 0 8 date}.${commit}";

    nixpkgsForHost = host:
      import inputs.nixpkgs {
        overlays = [overlay];
        system = host;
      };

    nixpkgs."aarch64-darwin" = nixpkgsForHost "aarch64-darwin";
    nixpkgs."aarch64-linux" = nixpkgsForHost "aarch64-linux";
    nixpkgs."i686-linux" = nixpkgsForHost "i686-linux";
    nixpkgs."x86_64-darwin" = nixpkgsForHost "x86_64-darwin";
    nixpkgs."x86_64-linux" = nixpkgsForHost "x86_64-linux";

    fenix."x86_64-linux" = inputs.fenix.packages."x86_64-linux";

    overlay = final: prev: {
      alejandra = final.rustPlatform.buildRustPackage {
        pname = "alejandra";
        inherit version;
        src = ./.;
        cargoLock.lockFile = ./Cargo.lock;

        passthru.tests = {
          version = final.testVersion {package = prev.alejandra;};
        };

        meta = {
          description = "The Uncompromising Nix Code Formatter.";
          homepage = "https://github.com/kamadorueda/alejandra";
          license = final.lib.licenses.unlicense;
          maintainers = [final.lib.maintainers.kamadorueda];
          platforms = final.lib.systems.doubles.all;
          mainProgram = "alejandra";
        };
      };
    };

    buildBinariesForHost = host: pkgs: let
      binaries = builtins.listToAttrs (
        builtins.map (pkg: {
          name = "alejandra-${pkg.stdenv.targetPlatform.config}";
          value = pkg;
        })
        pkgs
      );
    in
      binaries
      // {
        "alejandra-binaries" = nixpkgs.${host}.linkFarm "alejandra-binaries" (
          nixpkgs.${host}.lib.mapAttrsToList
          (name: binary: {
            inherit name;
            path = "${binary}/bin/alejandra";
          })
          binaries
        );
        "default" = builtins.elemAt pkgs 0;
      };
  in rec {
    checks."aarch64-darwin" = packages."aarch64-darwin";
    checks."aarch64-linux" = packages."aarch64-linux";
    checks."i686-linux" = packages."i686-linux";
    checks."x86_64-darwin" = packages."x86_64-darwin";
    checks."x86_64-linux" = packages."x86_64-linux";

    defaultPackage."aarch64-darwin" = packages."aarch64-darwin"."alejandra-aarch64-apple-darwin";
    defaultPackage."aarch64-linux" = packages."aarch64-linux"."alejandra-aarch64-unknown-linux-gnu";
    defaultPackage."i686-linux" = packages."i686-linux"."alejandra-i686-unknown-linux-gnu";
    defaultPackage."x86_64-darwin" = packages."x86_64-darwin"."alejandra-x86_64-apple-darwin";
    defaultPackage."x86_64-linux" = packages."x86_64-linux"."alejandra-x86_64-unknown-linux-gnu";

    devShell."x86_64-linux" = with nixpkgs."x86_64-linux";
      mkShell {
        name = "alejandra";
        packages = [
          cargo-bloat
          cargo-license
          cargo-tarpaulin
          jq
          inputs.fenix.packages."x86_64-linux".latest.rustfmt
          inputs.fenix.packages."x86_64-linux".stable.toolchain
          nodejs
          nodePackages.prettier
          perf
          shfmt
          treefmt
          yarn
          yarn2nix
        ];
      };

    inherit overlay;
    overlays.default = overlay;

    packages."aarch64-darwin" = with nixpkgs."aarch64-darwin";
      buildBinariesForHost "aarch64-darwin" [
        alejandra
      ];
    packages."aarch64-linux" = with nixpkgs."aarch64-linux";
      buildBinariesForHost "aarch64-linux" [
        alejandra
        pkgsStatic.alejandra
      ];
    packages."i686-linux" = with nixpkgs."i686-linux";
      buildBinariesForHost "i686-linux" [
        alejandra
      ];
    packages."x86_64-darwin" = with nixpkgs."x86_64-darwin";
      buildBinariesForHost "x86_64-darwin" [
        alejandra
      ];
    packages."x86_64-linux" = with nixpkgs."x86_64-linux";
      (buildBinariesForHost "x86_64-linux" [
        alejandra
        pkgsStatic.alejandra

        pkgsCross.aarch64-multiplatform.pkgsStatic.alejandra
        # Temporarily disabled to speed up release
        # pkgsCross.armv7l-hf-multiplatform.pkgsStatic.alejandra
        # pkgsCross.gnu32.pkgsStatic.alejandra
        # pkgsCross.raspberryPi.pkgsStatic.alejandra
      ])
      // {
        "alejandra-vscode-vsix" = mkYarnPackage {
          name = "alejandra";
          src = ./integrations/vscode;
          packageJSON = ./integrations/vscode/package.json;
          yarnLock = ./integrations/vscode/yarn.lock;
          yarnNix = ./integrations/vscode/yarn.lock.nix;
        };
        "build-wasm" = writeShellApplication {
          name = "build-wasm";
          runtimeInputs = [
            (fenix."x86_64-linux".combine [
              fenix."x86_64-linux".latest.rustc
              fenix."x86_64-linux".latest.toolchain
              fenix."x86_64-linux".targets."wasm32-unknown-unknown".latest.rust-std
            ])
            binaryen
            pkg-config
            openssl
            wasm-pack
          ];
          text = ''
            target="''${1:-web}"
            case "''${target}" in
              web|nodejs) ;;
              *) echo "unsupported wasm target: ''${target}" >&2; exit 2 ;;
            esac
            cd src/alejandra_wasm
            wasm-pack build --target "''${target}"
          '';
        };
      };
  };
}
